

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class OddServlet
 */
@WebServlet("/OddServlet")
public class OddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//int j,count=0;
		String sInput=request.getParameter("input");
		
		/*for(i=0;i<sInput.length();i++)
		{
			if(sInput.charAt(i)!=' ')
			{
				count++;
			}
				
		}
		
		int arr[]=new int[count];
		
		for(i=0,j=0;i<sInput.length() && j<count;i++)
		{
			if(sInput.charAt(i)!=' ')
			{
				arr[j]=Integer.parseInt(String.valueOf(sInput.charAt(i)));
				j++;
			}
		}*/
		String[] tokens = sInput.split(" ");
		int[] arr = new int[tokens.length];

		int i = 0;
		for (String token : tokens){
		    arr[i++] = Integer.parseInt(token); 
		}
		
		PrintWriter pw=response.getWriter();
		String sorted=OddSort.sort(arr);
		
		pw.print(sorted+" ");
		pw.println();
		
}
}