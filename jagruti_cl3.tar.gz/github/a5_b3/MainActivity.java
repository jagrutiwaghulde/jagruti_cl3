package com.example.jag.myapplication_testtt;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ip1,ip2;
    double input1,input2,final_result;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    public static final String MyPREFERENCES="MyPrefs";
    public static final String Name="nameKey";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ip1=findViewById(R.id.ip1);
        ip2=findViewById(R.id.ip2);
        sharedPreferences=getSharedPreferences(MyPREFERENCES,Context.MODE_PRIVATE);
    }

    public void clear(View view)
    {
        ip1.setText("");
        ip2.setText("");
    }

    public void tri_fun(View view)
    {
        input1=Double.parseDouble(ip1.getText().toString());

        double rad=Math.toRadians(input1);
        switch(view.getId())
        {
            case R.id.Sin:
                final_result=Math.sin(rad);
                break;
            case R.id.Cos:
                final_result=Math.cos(rad);
                break;
            case R.id.Tan:
                final_result=Math.tan(rad);
                break;
            case R.id.equall:
                ip1.setText(final_result+"");
                Toast.makeText(getApplicationContext(),final_result+"",Toast.LENGTH_SHORT).show();
            case R.id.sqrt:
                int temp=(int)Math.round(rad);
                final_result=Math.sqrt(temp);
                break;

        }
    }

    public void operator(View view)
    {
        input1=Double.parseDouble(ip1.getText().toString());
        input2=Double.parseDouble(ip2.getText().toString());

        switch(view.getId())
        {
            case R.id.plus:
                final_result=input1+input2;
                break;
            case R.id.minus:
                final_result=input1-input2;
                break;
            case R.id.mul:
                final_result=input1*input2;
                break;
            case R.id.div:
                if(input1<input2)
                    Toast.makeText(getApplicationContext(),"cannot perform division",Toast.LENGTH_SHORT).show();
                else if(input2==0)
                    Toast.makeText(getApplicationContext(),"Divide By Zero Error",Toast.LENGTH_SHORT).show();
                else
                    final_result=input1/input2;
                break;

        }
    }

    public void mem_fun(View view)
    {
        switch(view.getId())
        {
            case R.id.mems:
                editor=sharedPreferences.edit();
                editor.putString(Name,final_result+"");
                editor.commit();
                Toast.makeText(getApplicationContext(),"Saved",Toast.LENGTH_SHORT).show();
                break;
            case R.id.memr:
                if(sharedPreferences.getAll().containsKey(Name))
                {
                    ip1.setText(sharedPreferences.getString(Name,""));
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"There is no data which is saved!",Toast.LENGTH_SHORT).show();
                }break;

            case R.id.memc:
                editor=sharedPreferences.edit();
                editor.clear();
                editor.commit();
                Toast.makeText(getApplicationContext(),"Cleared",Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
